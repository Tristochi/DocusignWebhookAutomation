from azure.identity.aio import ClientSecretCredential
from msgraph.graph_service_client import GraphServiceClient
import asyncio
import requests
import json
import copy
import os
import sys

class Graph:
    client_credential: ClientSecretCredential
    app_client: GraphServiceClient

    def __init__(self, config):
        self.settings = json.loads(config) 
        self.base_url = 'https://graph.microsoft.com/v1.0/'
        #self.site_id = 'vnshs.sharepoint.com,1eda6640-d353-43d6-8464-ceada0d0129c,54954091-db81-4768-ae6c-d0e11d03eff9'
        self.site_id = '1eda6640-d353-43d6-8464-ceada0d0129c'
        self.main_site_id = 'b91d8aae-34a4-4698-ae2a-000c3254a098'
        self.document_lib_driveID = 'b!QGbaHlPT1kOEZM6toNASnJFAlVSB22hHrmzQ4R0D7_lLpbMpPyO2SZ2JbeP4e475'
        self.document_lib_itemID = '01V6NLD7V6Y2GOVW7725BZO354PWSELRRZ'
        client_id = self.settings['clientId']
        tenant_id = self.settings['tenantID']
        client_secret = self.settings['clientSecret']

        self.client_credential = ClientSecretCredential(tenant_id, client_id, client_secret)
        

    async def get_app_only_token(self):
        graph_scope = 'https://graph.microsoft.com/.default'
        access_token = await self.client_credential.get_token(graph_scope)
        await self.client_credential.close()
        return access_token.token

    async def get_protection_templates(self):
        token = await self.get_app_only_token()
        header = {
            'Authorization': f'Bearer {token}',
            'Content-type': 'application/json'
        }

        r = requests.get("https://graph.microsoft.com/v1.0/informationProtection/policy/templates", headers=header)
        print(json.dumps(r.json(), indent=4))

    async def get_sensitivity_labels(self):
        token = await self.get_app_only_token()
        header = {
            'Authorization': f'Bearer {token}',
            'Content-type': 'application/json'
        }
        r = requests.get("https://graph.microsoft.com/v1.0/me/informationProtection/sensitivityLabels", headers=header)
        print(json.dumps(r.json(), indent=4))


    async def send_email(self, message_content: dict):
        """
        message_content is a dict that takes\n 
        {
            'message': {
                'subject': '',
                'body': {
                    'contentType': 'Text',
                    'content': ''
                },
                'toRecipients': [
                    {
                        'emailAddress': {
                            'address': 'example@domain.com'
                        }
                    },
                    {
                        'emailAddress': {
                            'address': 'user2@domain.com'
                        }
                    }
                ]
            }
        }
        """
        token = await self.get_app_only_token()
        header = {
            'Authorization': f'Bearer {token}',
            'Content-type': 'application/json'
        }
        # 9f5b62b4-6d19-4a3d-a019-fc58bebfb59a
        # https://graph.microsoft.com/beta/users/69234dbb-ff5e-40df-a78b-9474d9bee56d/sendMail
        r = requests.post('https://graph.microsoft.com/beta/users/69234dbb-ff5e-40df-a78b-9474d9bee56d/sendMail', headers=header, json=message_content)
        
        return f'Email status code: {r.status_code} \n content: {r.content}'
    
    async def get_drives(self, site_id):
        #result = await self.app_client.sites.get()
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        #Get site meta-data
        result = requests.get('https://graph.microsoft.com/v1.0/sites/'+site_id+'/drives', headers=header)
        return result.json()

    async def get_drive_information(self, site_id):
        #Query to get file information
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }        
        result = requests.get("https://graph.microsoft.com/v1.0/sites/"+ site_id +"/drive/root/search(q='{Patient}')", headers=header)
        return result.json()

    async def delete_file(self, file_name):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }

        # Find file ID
        print(f'URL: https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/root/search(q=\'{file_name}\')')
        result = requests.get(f'https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/root/search(q=\'{file_name}\')', headers=header)
        print(json.dumps(result.json(), indent=4))

        file_id = result.json()['value'][0]['id']
        print(f'File id: {file_id}')
        result = requests.delete(f'https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/items/{file_id}', headers= header)
        print(f"Delete output: {result.content}")

    async def permanent_delete(self, drive_id, file_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.post(f'https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{file_id}/permanentDelete', headers= header)
        print(f'Result: \n{result.content}')

    async def get_lists(self, site_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.get(f'https://graph.microsoft.com/v1.0/sites/{site_id}/lists', headers=header)
        return result.json()
    
    async def get_list_items(self, site_id, list_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.get(f'{self.base_url}sites/{site_id}/lists/{list_id}/items?expand=fields', headers=header)
        return result.json()
    
    async def get_list_columns(self, site_id, list_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.get(f'{self.base_url}sites/{site_id}/lists/{list_id}/columns', headers=header)
        return result.json()
    

    async def create_new_list_item(self, site_id, list_id, fields):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }
        result = requests.post(f'{self.base_url}sites/{site_id}/lists/{list_id}/items', headers=header, data=json.dumps(fields))
        print(result.status_code)
        print(result.content)
        print(result.headers)
        return result.json()

    async def get_sites(self, site_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.get(f'https://graph.microsoft.com/v1.0/sites/{site_id}/sites', headers=header)
        return result.json()        

    async def get_pages(self, site_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.get(f'https://graph.microsoft.com/v1.0/sites/{site_id}/pages', headers=header)
        return result.json()       

    async def search_file(self, file_name, parent_id, site_id=None, drive_id=None):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }

        # Find file ID
        if site_id != None:
            print(f'URL: https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root/search(q=\'{file_name}\')')
            result = requests.get(f'https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root/search(q=\'{file_name}\')', headers=header)
            print(json.dumps(result.json(), indent=4))
            if len(result.json()['value']) > 0:
                return result.json()['value'][0]['id']
            else:
                return ''
        if drive_id != None:
            print(f'URL: https://graph.microsoft.com/v1.0/drives/{drive_id}/root/search(q=\'{file_name}\')')
            result = requests.get(f'https://graph.microsoft.com/v1.0/drives/{drive_id}/root/search(q=\'{file_name}\')', headers=header)
            #return json.dumps(result.json(),indent=4)
            if "value" in result.json():
                if len(result.json()["value"]) > 0:
                    for item in result.json()["value"]:
                        if item["parentReference"]["id"] == parent_id and item["name"] == file_name:
                            return item["id"]
                    return result.json()["value"][0]["id"]
            else:
                return ''
            

    async def upload_single_file(self, parent_id, drive_id, file_path='', item_id=None,file_name=None,file=None ):
        token = await self.get_app_only_token()
        file_type = file_path[-3:]
        print(file_type)
        if file_type == "csv":
            header = {
                'Authorization': 'Bearer ' + token,
                'Content-Type': 'text/csv',
                'Prefer': 'respond-async'
            }
        else:
            header = {
                'Authorization': 'Bearer ' + token,
                'Content-Type': f'application/{file_type}',
                'Prefer': 'respond-async'
            }
        if file_path != '':
            if "\\" in file_path:
                file_name = file_path.split("\\")
            elif "/" in file_path:
                file_name = file_path.split('/')
            file_name = file_name[-1]
            print(f'File name: {file_name}')

            #Upload a file to SharePoint
            result = requests.put(f'{self.base_url}drives/{drive_id}/items/{parent_id}:/{file_name}:/content', headers=header, data=open(file_path, 'rb'))
            print(result.content)
        else:
            file.seek(0)
            result = requests.put(f'{self.base_url}drives/{drive_id}/items/{parent_id}:/{file_name}:/content', headers=header, data=file.read())
            #result = requests.put(f'{self.base_url}sites/{site_id}/drive/items/{item_id}/content', headers=header, data=file.read())
            print(result.content)
            return result.status_code

    async def discard_checkout(self, drive_id, item_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.post(f'https://graph.microsoft.com/beta/drives/{drive_id}/items/{item_id}', headers=header)
        print(result.content)
        

    async def check_in_file(self, site_id, item_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.post(f'{self.base_url}sites/{site_id}/drive/items/{item_id}/checkout', headers=header)
        return result.status_code
    
    async def check_out_file(self, site_id, item_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.post(f'{self.base_url}sites/{site_id}/drive/items/{item_id}/checkin', headers=header)
        return result.status_code        

    async def download_drive_item(self, drive_id, drive_item_id):
        token = await self.get_app_only_token()
        header = {
            'Authorization': 'Bearer ' + token
        }
        result = requests.get(f'https://graph.microsoft.com/v1.0/drives/{drive_id}/items/{drive_item_id}/content', headers=header)
        return result.content

    async def upload_large_file(self, drive_id, parent_id, file_path):
        token = await self.get_app_only_token()
        file_type = file_path[-3:]
        print(f'File type: {file_type}')
        header = {
            'Authorization': 'Bearer ' + token,
            'Content-type': f'application/{file_type}'
        }
        #if "\\" in file_path: 
        #    last_index = file_path.rfind('\\')
        #elif "/" in file_path:
        #    last_index = file_path.rfind("/")

        file_name =  os.path.split(file_path)[1]

        #file_name = file_path[last_index+1:]
        print(f'File name: {file_name}')

        # Start upload session and grab link to send file contents to
        result = requests.post(f'{self.base_url}drives/{drive_id}/items/{parent_id}:/{file_name}:/createUploadSession', headers=header)
        print(result.content)
        upload_url = result.json()["uploadUrl"]
        print("the url is " + upload_url)

        # Upload file in 32 KiB chunks until file is complete.
        size = 320 * 1024
        with open(os.path.expandvars(file_path), 'rb') as file:
            file_size = len(file.read())
            print(file_size)
            file.seek(0)           
        
            start_byte= 0
            end_byte = size-1
            
            while True:
                chunk = file.read(size)
                print(f'length is {len(chunk)}')
                print(f'Content-Range bytes {start_byte}-{start_byte+len(chunk)-1}/{file_size}')
                
                header = {
                    'Authorization': 'Bearer ' + token,
                    'Content-type': f'application/{file_type}',
                    'Content-Range': f'bytes {start_byte}-{start_byte+len(chunk)-1}/{file_size}',
                    'Content-Length': str(len(chunk))
                }

                #upload_url = 'https://vnshs.sharepoint.com/sites/EmergencyPreparedness/_api/v2.0/drives/b!QGbaHlPT1kOEZM6toNASnJFAlVSB22hHrmzQ4R0D7_lLpbMpPyO2SZ2JbeP4e475/items/01V6NLD7R4HYLTCRWNXZFZ2YZWJJ4HXBRT/uploadSession?guid=\'c05faf25-04f3-49c4-a6dd-6b67eb763e63\'&overwrite=True&rename=False&dc=0&tempauth=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHBfZGlzcGxheW5hbWUiOiJab2hvRW1haWxOb3RpZmljYXRpb25zIiwiYXVkIjoiMDAwMDAwMDMtMDAwMC0wZmYxLWNlMDAtMDAwMDAwMDAwMDAwL3Zuc2hzLnNoYXJlcG9pbnQuY29tQGRkNjVlMmY3LWU3MGUtNGI4OS1iYTM4LWUxNjcwN2U5N2NiYiIsImNpZCI6InZFK0VzSFMvS2thNWdrcnZ3UWRWTHc9PSIsImVuZHBvaW50dXJsIjoiNmowM0dONzRta2trMTNHbWRxeXIwbjRnYTlCZnBUTVFmVzJRYkIvRUpiMD0iLCJlbmRwb2ludHVybExlbmd0aCI6IjI3MiIsImV4cCI6IjE3MTU4Nzc5NTIiLCJpcGFkZHIiOiIyMC4xOTAuMTUxLjM4IiwiaXNsb29wYmFjayI6IlRydWUiLCJpc3MiOiIwMDAwMDAwMy0wMDAwLTBmZjEtY2UwMC0wMDAwMDAwMDAwMDAiLCJuYW1laWQiOiJlMGY0YWI5MC0zNWYwLTRhOWUtODJkYy00NGNhNGEzZjQxZGVAZGQ2NWUyZjctZTcwZS00Yjg5LWJhMzgtZTE2NzA3ZTk3Y2JiIiwibmJmIjoiMTcxNTc5MTU1MiIsInJvbGVzIjoiYWxsc2l0ZXMud3JpdGUgYWxsc2l0ZXMuZnVsbGNvbnRyb2wiLCJzaXRlaWQiOiJNV1ZrWVRZMk5EQXRaRE0xTXkwME0yUTJMVGcwTmpRdFkyVmhaR0V3WkRBeE1qbGoiLCJ0dCI6IjEiLCJ2ZXIiOiJoYXNoZWRwcm9vZnRva2VuIn0.7EZqtQfSFUUHg0vC03EAzeBnAh862Kgyp8qEefQyBo4'
                print(len(chunk))
                result = requests.put(upload_url, headers=header, data=chunk)
                print(result.content)
                if end_byte >= (file_size-1):
                    break
                if len(chunk) == 0:
                    break
                start_byte = end_byte+1
                if (end_byte+size) >= file_size:
                    print("next is last iteration")
                    end_byte = file_size - 1
                    size = end_byte - start_byte+1
                else:
                    end_byte = end_byte+len(chunk)