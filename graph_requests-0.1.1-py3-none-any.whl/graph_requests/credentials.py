import os 
import json 
import sys 

if getattr(sys, 'frozen', False):
    app_path = os.path.dirname(sys.executable)
else:
    app_path = os.path.dirname(os.path.abspath(str(sys.modules['__main__'].__file__)))    
config = os.path.join(app_path, 'config.json')
class Credentials:
    def __init__(self, config_path = config):
        print(f"Looking for config at: {config_path}")
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file {config_path} not found.")
        
        with open(config, 'r') as file:
            try:
                data = json.loads(file.read())
            except json.JSONDecodeError:
                raise ValueError(f"Config file {config_path} contains invalid JSON.")
            
            self.username = data["username"]
            self.password = data["password"]

            if not self.username or not self.password:
                raise ValueError("Missing 'username' or 'password'in config file.")